package Org.Project;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Search1
 */
public class Search1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Search1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		Connection cn;
		Statement smt;
		ResultSet rs;
		
		 int d=Integer.parseInt(request.getParameter("id"));
		 // String a=request.getParameter("nm");
		 // int b=Integer.parseInt(request.getParameter("cn"));
		
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
            cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			
			smt=cn.createStatement();
			
			rs=smt.executeQuery("select * from contact1 where id ="+d);
			
			
			//out.print(rs.getString("d")+rs.getString("a")+rs.getString("b"));
			
			while(rs.next())
			{
				out.print(rs.getString("Id")+" "+rs.getString("name")+" "+rs.getString("contact"));
			}
			
			rs.close();
			smt.close();
			cn.close();
		}
		catch (Exception e)
		{
		   System.out.println(e);	
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
