package Org.Project;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Delete1
 */
public class Delete1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Delete1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  
		PrintWriter out=response.getWriter();
				response.setContentType("text/html");
				
				Connection cn;
				Statement smt;
				ResultSet rs;
				
				 int d=Integer.parseInt(request.getParameter("id"));
				
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					
		            cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
					
					smt=cn.createStatement();
					
					smt.executeUpdate("delete from contact1 where id = "+d);
					
					out.print("data deleted successfully");
					
					smt.close();
					cn.close();
				}
				catch (Exception e)
				{
					System.out.println(e);
				}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
