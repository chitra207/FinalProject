package dem.Pro;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class search
 */
@WebServlet("/search")
public class search extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public search() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String se=request.getParameter("se");
		 Connection cn;
			Statement smt;
			ResultSet rs;
			
		    try 
		     {
		    	 Class.forName("oracle.jdbc.driver.OracleDriver");    //DriverLoading
		    	 //Register Driver
		    	 cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
		    	
				smt=cn.createStatement();
			rs=	smt.executeQuery("select name,roll,per,gra from std2 where roll=" + se);

			
         while(rs.next())
         {
        	  out.println("<table border=1>");
              out.println("<tr><td>"+" Name "+"</td>"+"<td>"+" Roll No "+"<td>"+" Percentage "+"<td>"+" Grade "+"</td></tr>");
              out.println("<tr><th>"+rs.getString(1)+"</th>"+"<th>"+rs.getString(2)+"</th>"+"<th>"+rs.getString(3)+"<th>"+rs.getString(4)+"</th></tr>");

        	  out.println("</table");

         }
				smt.close();
		    	cn.close();
		     }
		     catch(Exception e)
		     {
		    	 
		     } 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
