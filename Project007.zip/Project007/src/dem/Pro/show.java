package dem.Pro;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class show
 */
@WebServlet("/show")
public class show extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public show() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		 Connection cn;
			Statement smt;
			ResultSet rs;
			
		    try 
		     {
		    	 Class.forName("oracle.jdbc.driver.OracleDriver");    //DriverLoading
		    	 //Register Driver
		    	 cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
		    	
				smt=cn.createStatement();
			rs=	smt.executeQuery("select * from std2");

			out.println("<table border=1>");
            out.println("<tr><td>"+" Name "+"</td>"+"<td>"+" Roll No "+"<td>"+" Physics "+"<td>"+" Maths "+"<td>"+" Chemistry "+"<td>"+" Biology "+"<td>"+" C.S "+"</td></tr>");
         while(rs.next())
         {
        	  
              out.println("<tr><th>"+rs.getString(1)+"</th>"+"<th>"+rs.getString(2)+"</th>"+"<th>"+rs.getString(3)+"<th>"+rs.getString(4)+"<th>"+rs.getString(5)+"<th>"+rs.getString(6)+"<th>"+rs.getString(7)+"</th></tr>");
        	 

         }
				smt.close();
		    	cn.close();
		     }
		     catch(Exception e)
		     {
		    	 
		     } 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
