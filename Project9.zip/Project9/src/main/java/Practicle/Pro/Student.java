package Practicle.Pro;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/Get")
public class Student {

	@GET
	@Path("/add/{roll}/{name}/{age}/{address}")
	public String getXMLstudent(@PathParam("roll") int roll,@PathParam("name") String name,@PathParam("age") int age,@PathParam("address") String address)
	{
		Connection cn;
		Statement smt;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			
			smt=cn.createStatement();
			smt.executeUpdate("insert into student values('"+roll+"','"+name+"','"+age+"','"+address+"')");
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return "data saved sucessfully";
	}
	
	@GET
	@Path("/delete/{roll}")
	public String del(@PathParam("roll") int roll)
	{

		Connection cn;
		Statement smt;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			
			smt=cn.createStatement();
			smt.executeUpdate("delete from student where roll="+roll);
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return "data deleted sucessfully";
	}
	
	@GET
	@Path("/update/{roll}")
	public String up(@PathParam("roll") int roll)
	{

		Connection cn;
		Statement smt;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			
			smt=cn.createStatement();
			smt.executeUpdate("update student set address='Nashik' where roll="+roll);
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return "data updated sucessfully";
	}
	
	@GET
	@Path("/display")
	public String show()
	{

		Connection cn;
		Statement smt;
		ResultSet rs;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","root");
			
			smt=cn.createStatement();
			
			rs=smt.executeQuery("select * from student");
			
			
			while(rs.next())
			{
			System.out.print(+rs.getInt("roll")+" "+rs.getString("name")+" "+rs.getInt("age")+" "+rs.getString("address"));	
			}
			
			
			rs.close();
			smt.close();
			cn.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return "data display sucessfully";
	}
}
